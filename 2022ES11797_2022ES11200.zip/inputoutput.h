#ifndef INPUTOUTPUT_H
#define INPUTOUTPUT_H

#include "input.h"
#include <string>
#include <map>
Problem read_input(string filename);
map<int, bool> read_output(string filename);
#endif